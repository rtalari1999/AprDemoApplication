console.log("Hello World!")

var courseName : string = ' Angular Course';
courseName = 'HTML Course';
courseName = " CSS Course ";

var age: number = 10;

age= 25;


var idWithoutValue: string;

idWithoutValue = 'Hello world!';

var userName = 99;
userName = 55;

var userEmail ;

userEmail= 99;
userEmail = 'Exapmle@gmail.com';
userEmail = true;
userEmail = null;
userEmail = undefined;


   


class Example{
/* Hello world
 is the basic program


 I have been started to learn ts
*/


    //start with lower case as well as upper-case

     
     sub = 10 //valid
     Multi = 10 // valid


    // cannot start with number
     //1Add = 10; // invalid

     add1 = 10; // valid

     //Symbols

     Add_ = 10 // valid
     add$ = 10 // valid
     add = 10
     _add = 10; // valid
     $add = 10; // valid
     _$add =  10; // valid


     // case sensitive

     example = 'Hello World!';
     Example = ' Case Sensitive';
     ExAmple = 10;

}



