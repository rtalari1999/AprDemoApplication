var num1 : number = 1; // integer

var num2 : number = 10.01; // floating 

var num3 : number = 0x37CF; // hexa decimal

var num4 : number = 0b111001; // binary


console.log('num1' , num1 )
console.log('num2' , num2 )
console.log('num3' , num3 )
console.log('num4' , num4 )

// string is nothing but sequence of characters.
var str : string = 'string Example';
var str1: string = "double quotes";
var str2 : string = `Backticks`;
var str3 : string = 'true';


console.log('str' , str )
console.log('str1' , str1 )
console.log('str2' , str2 )
console.log('str3' , typeof(str3) )

// boolean Represents true or false


var b : boolean = true;
var b1 : boolean = false;

console.log('b', b);
console.log('b1', b1);

// void
var v : void = undefined;

function v1(): void{
    console.log('Example of void');
}

// null

var n : null = null;

var n1 : null  = null;

// undefined

var ud : undefined = undefined;
var ud1 : string = 'string';

console.log('ud1', ud1)

// any

var a : any = 0b111001; // valid

a = 'String';

a = true;

a = false;

a = null;

a = undefined;

a = [1,2,34];










