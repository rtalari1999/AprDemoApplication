var num1 = 1; // integer
var num2 = 10.01; // floating 
var num3 = 0x37CF; // hexa decimal
var num4 = 57; // binary
console.log('num1', num1);
console.log('num2', num2);
console.log('num3', num3);
console.log('num4', num4);
// string is nothing but sequence of characters.
var str = 'string Example';
var str1 = "double quotes";
var str2 = "Backticks";
var str3 = 'true';
console.log('str', str);
console.log('str1', str1);
console.log('str2', str2);
console.log('str3', typeof (str3));
// boolean Represents true or false
var b = true;
var b1 = false;
console.log('b', b);
console.log('b1', b1);
// void
var v = undefined;
function v1() {
    console.log('Example of void');
}
// null
var n = null;
var n1 = null;
// undefined
var ud = undefined;
var ud1 = undefined;
console.log('ud1', ud1);
