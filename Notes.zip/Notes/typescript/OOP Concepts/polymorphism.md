What is polymorphism in Typescript?
===================================
Poly + Morphism = polymorphism
    - Polymorphism is the concept of object-oriented programming in Typescript.
    where poly means "many" and morphism means "transforming one form into another form"

What is method or function signiture?
=====================================
    - A method or function signiture defines the input parameters and their types and also the expected return type for that function or method.

