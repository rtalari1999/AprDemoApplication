Control flow
============================

    1. Comparison operators
    2. if else
    3. for loop
    4. while loop
    5. do while
    6. break statement
    7. continue statement

    callback functions


1. Comparison Operators:
==========================
    - Comparison Operators compare two values and return a boolean value(true or false).

    Commonly used comparison operators:
    =====================================

    Operator        Meaning             Example
    ==              Equal to            3 ==  5 // false
    !=              Not Equal to        3 != 5 //true

    ===             Strictly equal to   3 === '3' // false
    !==             Strictly not equal to 3 !== '3' // true
    >                Greater than           4 > 5 //false
    <                  Less than            4 < 5 // true
    >=              Greater than or equal to 4 >= 4 //true
    <=              Less than or equal to   3 <= 3 // true